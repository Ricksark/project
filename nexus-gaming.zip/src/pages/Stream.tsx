import { useState, useEffect, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { db } from "../lib/firebase";
import { doc, getDoc, updateDoc, increment } from "firebase/firestore";
import { User } from "firebase/auth";
import socket from "../lib/socket";
import { motion, AnimatePresence } from "motion/react";
import { Send, Users, Activity, Terminal, Shield } from "lucide-react";

interface Message {
  id?: string;
  user: string;
  text: string;
  timestamp: number;
}

interface StreamData {
  id: string;
  title: string;
  url: string;
  viewers: number;
}

export default function Stream({ user }: { user: User | null }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const [stream, setStream] = useState<StreamData | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [viewers, setViewers] = useState(0);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!id) return;

    const fetchStream = async () => {
      const docRef = doc(db, "streams", id);
      const snap = await getDoc(docRef);
      if (snap.exists()) {
        setStream({ id: snap.id, ...snap.data() } as StreamData);
        setViewers(snap.data().viewers || 0);
      } else {
        navigate("/");
      }
    };

    fetchStream();

    // Socket listeners
    socket.emit("join-stream", id);
    
    socket.on("new-chat-message", (msg: Message) => {
      setMessages(prev => [...prev.slice(-49), msg]);
    });

    socket.on(`stream:${id}:viewers`, (count: number) => {
      setViewers(count);
    });

    // Track view (Upstash integration)
    fetch(`/api/views/${id}`, { method: 'POST' });

    return () => {
      socket.off("new-chat-message");
      socket.off(`stream:${id}:viewers`);
    };
  }, [id, navigate]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || !user) return;

    const msg: Message = {
      user: user.displayName || "Anonymous Node",
      text: input,
      timestamp: Date.now()
    };

    socket.emit("send-message", { streamId: id, ...msg });
    setInput("");
  };

  if (!stream) return null;

  return (
    <div className="max-w-[1920px] mx-auto grid grid-cols-1 lg:grid-cols-4 h-[calc(100vh-64px)] overflow-hidden">
      {/* Player Section */}
      <div className="lg:col-span-3 bg-black flex flex-col h-full border-r border-white/10">
        <div className="flex-1 relative bg-black flex items-center justify-center">
          <div className="w-full aspect-video bg-[#0a0a0a] relative group">
             {/* Fake Player Placeholder */}
             <div className="absolute inset-0 flex items-center justify-center overflow-hidden">
                <div className="absolute inset-0 opacity-20 pointer-events-none">
                  <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-[#00FF00]/20 via-transparent to-transparent" />
                </div>
                <div className="text-center z-10">
                   <div className="flex justify-center mb-6">
                      <div className="relative">
                         <div className="absolute inset-0 blur-2xl bg-[#00FF00]/40 rounded-full animate-pulse" />
                         <Shield className="w-24 h-24 text-[#00FF00] relative" />
                      </div>
                   </div>
                   <h2 className="text-3xl font-black uppercase tracking-tighter italic text-white/80">Stream Connection Established</h2>
                   <p className="font-mono text-xs uppercase tracking-[0.4em] text-white/40 mt-2">Node: {stream.id}</p>
                </div>
                {/* Visual scanline effect */}
                <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_4px,3px_100%] pointer-events-none" />
             </div>
          </div>
        </div>
        
        <div className="p-6 bg-[#0a0a0a] border-t border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-4">
             <div className="bg-red-600 px-3 py-1 text-xs font-black uppercase tracking-widest animate-pulse flex items-center gap-2">
                <span className="w-2 h-2 bg-white rounded-full" />
                Live
             </div>
             <div>
                <h1 className="text-2xl font-black uppercase tracking-tighter italic">{stream.title}</h1>
                <p className="text-[10px] font-mono uppercase tracking-[0.2em] text-white/40 mt-1">Operational ID: Nexus-01-Beta</p>
             </div>
          </div>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-white/40" />
              <span className="font-mono font-bold text-[#00FF00]">{viewers.toLocaleString()}</span>
            </div>
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-white/40" />
              <span className="font-mono text-xs text-white/40">1080P/60</span>
            </div>
          </div>
        </div>
      </div>

      {/* Chat Section */}
      <div className="lg:col-span-1 bg-[#0a0a0a] flex flex-col h-full">
        <div className="p-4 border-b border-white/10 flex items-center justify-between bg-[#0a0a0a]">
          <h2 className="font-bold uppercase tracking-widest text-sm flex items-center gap-2">
            <Terminal className="w-4 h-4 text-[#00FF00]" />
            Arena Comms
          </h2>
          <span className="text-[10px] font-mono text-white/40 transition-all">Protocol v4.2</span>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
          <AnimatePresence initial={false}>
            {messages.map((msg, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="group"
              >
                <div className="text-[10px] font-mono uppercase tracking-widest text-white/20 mb-1 leading-none">{msg.user}</div>
                <div className="text-sm bg-white/5 p-3 border-l-2 border-[#00FF00]/30 group-hover:bg-white/10 transition-colors">
                  {msg.text}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
          <div ref={chatEndRef} />
        </div>

        <div className="p-4 border-t border-white/10 bg-[#050505]">
          {user ? (
            <form onSubmit={sendMessage} className="relative">
              <input 
                type="text"
                placeholder="Broadcast a command..."
                className="w-full bg-[#0a0a0a] border border-white/10 px-4 py-4 pr-12 text-sm outline-none focus:border-[#00FF00] transition-colors font-mono"
                value={input}
                onChange={e => setInput(e.target.value)}
              />
              <button 
                type="submit"
                className="absolute right-3 top-1/2 -translate-y-1/2 p-2 text-white/40 hover:text-[#00FF00] transition-colors"
              >
                <Send className="w-5 h-5" />
              </button>
            </form>
          ) : (
            <div className="text-center py-4 bg-white/5 border border-dashed border-white/10">
              <p className="text-[10px] font-mono uppercase tracking-widest text-white/40">Authorization required to transmit.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
