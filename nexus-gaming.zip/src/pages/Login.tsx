import { useState } from "react";
import { signInWithPopup, GoogleAuthProvider, browserSessionPersistence, setPersistence } from "firebase/auth";
import { auth, db } from "../lib/firebase";
import { doc, getDoc, setDoc, serverTimestamp } from "firebase/firestore";
import { useNavigate } from "react-router-dom";
import { motion } from "motion/react";
import { LogIn, Github, Mail, ShieldCheck } from "lucide-react";

export default function Login() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleGoogleLogin = async () => {
    setLoading(true);
    setError("");
    const provider = new GoogleAuthProvider();
    try {
      await setPersistence(auth, browserSessionPersistence);
      const result = await signInWithPopup(auth, provider);
      
      // Check/Create User in Firestore
      const userRef = doc(db, "users", result.user.uid);
      const userSnap = await getDoc(userRef);

      if (!userSnap.exists()) {
        await setDoc(userRef, {
          uid: result.user.uid,
          email: result.user.email,
          displayName: result.user.displayName,
          photoURL: result.user.photoURL,
          role: "member", // Default role
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
      
      navigate("/");
    } catch (err) {
      console.error(err);
      setError("Authorization sequence failed. Connection rejected.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-64px)] flex items-center justify-center p-4 bg-[#050505]">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="w-full max-w-md bg-[#0a0a0a] border border-white/10 p-8 shadow-2xl relative overflow-hidden"
      >
        {/* Glow effect */}
        <div className="absolute -top-24 -left-24 w-48 h-48 bg-[#00FF00]/10 blur-[100px]" />
        
        <div className="relative z-10 text-center mb-12">
          <div className="inline-block bg-[#00FF00]/10 p-4 rounded-full mb-6">
            <ShieldCheck className="w-12 h-12 text-[#00FF00]" />
          </div>
          <h1 className="text-3xl font-black uppercase tracking-tighter italic mb-2">Access Portal</h1>
          <p className="text-white/40 font-mono text-xs uppercase tracking-widest">Establish a secure node connection</p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 text-red-500 text-xs font-mono uppercase tracking-widest text-center">
            {error}
          </div>
        )}

        <div className="space-y-4">
          <button 
            onClick={handleGoogleLogin}
            disabled={loading}
            className="w-full group bg-white text-black h-12 flex items-center justify-center gap-3 font-bold uppercase tracking-tighter hover:bg-[#00FF00] disabled:opacity-50 disabled:cursor-not-allowed transition-all"
          >
            <LogIn className="w-4 h-4 group-hover:scale-110 transition-transform" />
            {loading ? "Syncing..." : "Identify with Google"}
          </button>

          <button 
            disabled 
            className="w-full bg-white/5 border border-white/10 text-white/40 h-12 flex items-center justify-center gap-3 font-bold uppercase tracking-tighter cursor-not-allowed"
          >
            <Github className="w-4 h-4 opacity-30" />
            Github Link (Soon)
          </button>
        </div>

        <div className="mt-12 text-center">
          <div className="text-[10px] font-mono text-white/20 uppercase tracking-[0.2em] leading-relaxed">
            By accessing this node you agree to the Nexus Engagement Protocols and Data Synthesis Guidelines.
          </div>
        </div>
      </motion.div>
    </div>
  );
}
