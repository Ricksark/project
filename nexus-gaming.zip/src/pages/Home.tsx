import { useEffect, useState } from "react";
import { collection, query, where, getDocs, limit } from "firebase/firestore";
import { db } from "../lib/firebase";
import { Link } from "react-router-dom";
import { motion } from "motion/react";
import { Play, Radio, Users, Trophy, Zap } from "lucide-react";

interface Stream {
  id: string;
  title: string;
  streamerId: string;
  status: string;
  viewers: number;
  thumbnail?: string;
}

export default function Home() {
  const [streams, setStreams] = useState<Stream[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStreams = async () => {
      const q = query(collection(db, "streams"), where("status", "==", "live"), limit(6));
      const snapshot = await getDocs(q);
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Stream));
      setStreams(data);
      setLoading(false);
    };
    fetchStreams();
  }, []);

  return (
    <main className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative min-h-[80vh] flex items-center justify-center pt-20">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#050505]/50 to-[#050505]" />
          <motion.div 
            initial={{ scale: 1.2, opacity: 0 }}
            animate={{ scale: 1, opacity: 0.3 }}
            transition={{ duration: 2 }}
            className="w-full h-full bg-[url('https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80')] bg-cover bg-center"
          />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 text-center">
          <motion.div
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <h1 className="font-sans font-black text-7xl md:text-[12vw] uppercase leading-[0.8] tracking-tighter mb-8 italic">
              Level <span className="text-[#00FF00]">UP</span>
            </h1>
            <p className="max-w-2xl mx-auto text-lg text-white/60 font-mono uppercase tracking-widest mb-12">
              The premier ecosystem for competitive livestreaming and elite community interaction.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <button className="bg-[#00FF00] text-black px-8 py-4 font-black uppercase tracking-tighter hover:scale-105 transition-transform flex items-center gap-2">
                <Play className="w-5 h-5 fill-black" />
                Join Arena
              </button>
              <button className="border border-white/20 bg-white/5 backdrop-blur-sm px-8 py-4 font-black uppercase tracking-tighter hover:bg-white/10 transition-colors">
                Explore Meta
              </button>
            </div>
          </motion.div>
        </div>

        {/* Stats Strip */}
        <div className="absolute bottom-0 left-0 right-0 border-t border-white/10 bg-[#0a0a0a]">
          <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 divide-x divide-white/10">
            {[
              { label: "Active Players", value: "124K+", icon: Users },
              { label: "Live Streams", value: "842", icon: Radio },
              { label: "Tournaments", value: "12", icon: Trophy },
              { label: "Data Flow", value: "1.2GB/s", icon: Zap },
            ].map((stat, i) => (
              <div key={i} className="p-6 flex items-center gap-4 group hover:bg-white/5 transition-colors">
                <stat.icon className="w-5 h-5 text-[#00FF00] group-hover:scale-110 transition-transform" />
                <div>
                  <div className="text-xl font-black font-mono leading-none">{stat.value}</div>
                  <div className="text-[10px] uppercase tracking-widest text-white/40 mt-1">{stat.label}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Live Streams Section */}
      <section className="py-24 bg-[#050505]">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-end justify-between mb-12">
            <div>
              <div className="text-[#00FF00] font-mono text-sm tracking-[0.4em] uppercase mb-2">Broadcasting</div>
              <h2 className="text-4xl font-black uppercase tracking-tighter font-sans italic">Live Nodes</h2>
            </div>
            <Link to="/discover" className="text-sm font-mono uppercase text-white/40 hover:text-[#00FF00]">View Network</Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {loading ? (
              [...Array(3)].map((_, i) => (
                <div key={i} className="aspect-video bg-white/5 animate-pulse rounded-sm" />
              ))
            ) : streams.length > 0 ? (
              streams.map((stream) => (
                <motion.div 
                  key={stream.id}
                  whileHover={{ y: -10 }}
                  className="group"
                >
                  <Link to={`/stream/${stream.id}`} className="block">
                    <div className="relative aspect-video overflow-hidden bg-white/5 border border-white/10 group-hover:border-[#00FF00]/50 transition-colors">
                      <div className="absolute top-4 left-4 z-10">
                        <div className="bg-red-600 px-2 py-0.5 rounded-sm flex items-center gap-1.5 animate-pulse">
                          <div className="w-1.5 h-1.5 bg-white rounded-full" />
                          <span className="text-[10px] font-bold uppercase tracking-widest">Live</span>
                        </div>
                      </div>
                      <div className="absolute bottom-4 right-4 z-10">
                        <div className="bg-black/80 backdrop-blur-md px-2 py-1 rounded-sm text-[10px] font-mono border border-white/20">
                          {stream.viewers.toLocaleString()} VIEWS
                        </div>
                      </div>
                      <img 
                        src={stream.thumbnail || "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80"} 
                        alt={stream.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 opacity-60 group-hover:opacity-100"
                      />
                    </div>
                    <div className="mt-4">
                      <h3 className="font-bold text-lg leading-tight group-hover:text-[#00FF00] transition-colors">{stream.title}</h3>
                      <p className="text-white/40 text-xs font-mono uppercase mt-1 tracking-widest">Node ID: {stream.id.substring(0, 8)}</p>
                    </div>
                  </Link>
                </motion.div>
              ))
            ) : (
              <div className="col-span-full py-20 text-center border border-dashed border-white/10">
                <div className="text-white/20 font-mono uppercase tracking-widest">No active nodes detected in the arena.</div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Marquee Accent */}
      <div className="bg-[#00FF00] py-4 overflow-hidden border-y-2 border-black">
        <motion.div 
          animate={{ x: [0, -1000] }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="flex whitespace-nowrap gap-12"
        >
          {[...Array(10)].map((_, i) => (
            <span key={i} className="text-black font-black text-2xl uppercase tracking-tighter italic">
              Nexus Gaming System // Realtime Engagement // Infinite Streams // 010101 //
            </span>
          ))}
        </motion.div>
      </div>
    </main>
  );
}
