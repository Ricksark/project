import { Link, useNavigate } from "react-router-dom";
import { User, signOut } from "firebase/auth";
import { auth } from "../lib/firebase";
import { Gamepad2, User as UserIcon, LogOut, LayoutDashboard, Radio } from "lucide-react";
import { motion } from "motion/react";

interface NavbarProps {
  user: User | null;
  isAdmin: boolean;
}

export default function Navbar({ user, isAdmin }: NavbarProps) {
  const navigate = useNavigate();

  const handleLogout = async () => {
    await signOut(auth);
    navigate("/login");
  };

  return (
    <nav className="sticky top-0 z-50 border-b border-white/10 bg-[#050505]/80 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group">
          <div className="bg-[#00FF00] p-1.5 rounded-sm transform group-hover:rotate-12 transition-transform">
            <Gamepad2 className="w-6 h-6 text-black" />
          </div>
          <span className="font-sans font-bold text-xl uppercase tracking-tighter italic">Nexus</span>
        </Link>

        <div className="flex items-center gap-6">
          <Link 
            to="/" 
            className="text-sm font-mono uppercase tracking-widest text-white/70 hover:text-[#00FF00] transition-colors"
          >
            Lobby
          </Link>
          
          {user ? (
            <div className="flex items-center gap-4">
              {isAdmin && (
                <Link 
                  to="/admin" 
                  className="flex items-center gap-2 text-sm font-mono uppercase text-[#00FF00] border border-[#00FF00]/30 px-3 py-1 rounded-sm hover:bg-[#00FF00]/10 transition-colors"
                >
                  <LayoutDashboard className="w-4 h-4" />
                  Admin
                </Link>
              )}
              <div className="h-8 w-px bg-white/10 mx-2" />
              <div className="flex items-center gap-3">
                {user.photoURL ? (
                  <img src={user.photoURL} className="w-8 h-8 rounded-full border border-white/20" alt="Avatar" />
                ) : (
                  <UserIcon className="w-5 h-5 text-white/50" />
                )}
                <button 
                  onClick={handleLogout}
                  className="p-2 text-white/50 hover:text-white transition-colors"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            </div>
          ) : (
            <Link 
              to="/login"
              className="bg-white text-black px-6 py-2 text-sm font-bold uppercase tracking-tighter hover:bg-[#00FF00] transition-colors"
            >
              Initialize Session
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}
