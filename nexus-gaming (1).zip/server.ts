import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import path from "path";
import { createServer as createViteServer } from "vite";
import { Redis } from "@upstash/redis";
import dotenv from "dotenv";

dotenv.config();

const redis = process.env.UPSTASH_REDIS_REST_URL 
  ? new Redis({
      url: process.env.UPSTASH_REDIS_REST_URL,
      token: process.env.UPSTASH_REDIS_REST_TOKEN!,
    })
  : null;

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: {
      origin: "*",
    }
  });

  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Upstash Redis View Counter (Example Integration)
  app.post("/api/views/:streamId", async (req, res) => {
    const { streamId } = req.params;
    if (redis) {
      try {
        const views = await redis.incr(`stream:${streamId}:views`);
        io.emit(`stream:${streamId}:viewers`, views);
        res.json({ views });
      } catch (error) {
        res.status(500).json({ error: "Redis error" });
      }
    } else {
      res.status(503).json({ error: "Redis not configured" });
    }
  });

  // Socket.io for live chat/updates
  io.on("connection", (socket) => {
    console.log("A user connected:", socket.id);
    
    socket.on("join-stream", (streamId) => {
      socket.join(`stream-${streamId}`);
    });

    socket.on("send-message", (data) => {
      // data: { streamId, user, text }
      io.to(`stream-${data.streamId}`).emit("new-chat-message", data);
    });

    socket.on("disconnect", () => {
      console.log("User disconnected:", socket.id);
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
