# Security Specification - Nexus Gaming

## Data Invariants
1. A user can only edit their own profile, except for the 'role' field which is read-only for basic users.
2. Only Admins can create or update 'Stream' documents.
3. Every document must have a `createdAt` and `updatedAt`.
4. Streamer IDs in 'Stream' docs must match valid users.

## Dirty Dozen Payloads (Targeted for Rejection)
1. User profile creation with `role: 'admin'`.
2. Updating `role` from `member` to `admin` as a non-admin.
3. Creating a stream as a non-admin.
4. Updating a stream's `streamerId` to another user.
5. Injected script in `title` or `description` (Size and regex checks).
6. Deleting another user's profile.
7. Updating `createdAt` timestamp.
8. Writing to a random non-existent collection.
9. Querying all users' private data (Emails).
10. Creating a stream with a massive 1MB title string.
11. Updating a stream status without changing `updatedAt`.
12. Batch writing streams without proper admin auth.

## Test Runner Logic (Draft)
- `service cloud.firestore { ... }`
- `allow read, write: if false;` (Default Deny)
