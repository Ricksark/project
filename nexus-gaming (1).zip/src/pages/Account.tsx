import { User } from "firebase/auth";
import { doc, getDoc, updateDoc } from "firebase/firestore";
import { useEffect, useState } from "react";
import { db } from "../lib/firebase";
import { motion } from "motion/react";
import { UserCircle, Shield, Calendar, Mail, Save, Clock } from "lucide-react";

export default function Account({ user }: { user: User | null }) {
  const [profile, setProfile] = useState<any>(null);
  const [displayName, setDisplayName] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (user) {
      const fetchProfile = async () => {
        const snap = await getDoc(doc(db, "users", user.uid));
        if (snap.exists()) {
          setProfile(snap.data());
          setDisplayName(snap.data().displayName || "");
        }
      };
      fetchProfile();
    }
  }, [user]);

  const handleUpdate = async () => {
    if (!user) return;
    setLoading(true);
    try {
      await updateDoc(doc(db, "users", user.uid), {
        displayName,
        updatedAt: new Date(),
      });
      setMessage("Bio-matrix updated successfully.");
      setTimeout(() => setMessage(""), 3000);
    } catch (err) {
      console.error(err);
      setMessage("Update rejected by security protocols.");
    } finally {
      setLoading(false);
    }
  };

  if (!user || !profile) return null;

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="flex items-center gap-6 mb-12">
           <div className="relative group">
              <div className="absolute inset-0 bg-[#00FF00]/20 blur-xl opacity-0 group-hover:opacity-100 transition-opacity" />
              {user.photoURL ? (
                <img src={user.photoURL} className="w-24 h-24 rounded-sm border-2 border-[#00FF00]/50 relative z-10" alt="Avatar" />
              ) : (
                <div className="w-24 h-24 bg-white/5 border border-white/10 flex items-center justify-center rounded-sm relative z-10">
                  <UserCircle className="w-12 h-12 text-white/20" />
                </div>
              )}
           </div>
           <div>
              <h1 className="text-4xl font-display font-black uppercase tracking-tighter italic">Account Matrix</h1>
              <div className="flex items-center gap-3 mt-2">
                 <div className="bg-[#00FF00]/10 text-[#00FF00] px-2 py-0.5 rounded-sm text-[10px] font-mono font-bold uppercase tracking-widest border border-[#00FF00]/20">
                    {profile.role}
                 </div>
                 <div className="text-white/40 text-xs font-mono uppercase tracking-widest flex items-center gap-1">
                    <Shield className="w-3 h-3" />
                    Verified Agent
                 </div>
              </div>
           </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
           <div className="md:col-span-2 space-y-6">
              <div className="bg-[#0a0a0a] border border-white/10 p-8">
                 <h2 className="text-sm font-bold uppercase tracking-[0.2em] mb-8 border-b border-white/10 pb-4">Personal Ident</h2>
                 
                 <div className="space-y-6">
                    <div>
                       <label className="block text-[10px] uppercase tracking-widest text-white/40 mb-2">Display Alias</label>
                       <input 
                         type="text"
                         className="w-full bg-[#151619] border border-white/10 px-4 py-3 outline-none focus:border-[#00FF00] transition-colors font-mono text-sm"
                         value={displayName}
                         onChange={(e) => setDisplayName(e.target.value)}
                       />
                    </div>

                    <div>
                       <label className="block text-[10px] uppercase tracking-widest text-white/40 mb-2">Communication Link</label>
                       <div className="w-full bg-white/5 border border-white/5 px-4 py-3 font-mono text-sm text-white/30 cursor-not-allowed flex items-center gap-2">
                          <Mail className="w-4 h-4" />
                          {user.email}
                       </div>
                    </div>

                    <button 
                      onClick={handleUpdate}
                      disabled={loading}
                      className="bg-[#00FF00] text-black px-8 py-3 font-black uppercase tracking-tighter hover:scale-105 active:scale-95 transition-all flex items-center gap-2 disabled:opacity-50"
                    >
                      <Save className="w-4 h-4" />
                      {loading ? "Sycning..." : "Save Configuration"}
                    </button>

                    {message && (
                      <motion.p 
                        initial={{ opacity: 0 }} 
                        animate={{ opacity: 1 }} 
                        className="text-[10px] font-mono uppercase text-[#00FF00] tracking-widest"
                      >
                        {message}
                      </motion.p>
                    )}
                 </div>
              </div>
           </div>

           <div className="space-y-6">
              <div className="bg-[#0a0a0a] border border-white/10 p-6">
                 <h2 className="text-[10px] font-bold uppercase tracking-widest text-white/40 mb-6">Nexus Metrix</h2>
                 <div className="space-y-4">
                    <div className="flex justify-between items-center text-xs">
                       <div className="flex items-center gap-2 text-white/40 uppercase tracking-widest">
                          <Calendar className="w-3 h-3" />
                          Enrolled
                       </div>
                       <div className="font-mono text-[#00FF00]">
                          {profile.createdAt?.toDate ? profile.createdAt.toDate().toLocaleDateString() : 'N/A'}
                       </div>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                       <div className="flex items-center gap-2 text-white/40 uppercase tracking-widest">
                          <Clock className="w-3 h-3" />
                          Last Update
                       </div>
                       <div className="font-mono text-white/60 uppercase">
                          Just now
                       </div>
                    </div>
                 </div>
              </div>

              <div className="bg-red-500/5 border border-red-500/20 p-6">
                 <h2 className="text-[10px] font-bold uppercase tracking-widest text-red-500/80 mb-4">Danger Zone</h2>
                 <button className="w-full border border-red-500/30 text-red-500 py-2 text-[10px] font-bold uppercase tracking-widest hover:bg-red-500 hover:text-white transition-colors">
                    Terminate Session
                 </button>
              </div>
           </div>
        </div>
      </motion.div>
    </div>
  );
}
