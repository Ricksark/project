import { useState, useEffect, FormEvent } from "react";
import { db } from "../lib/firebase";
import { collection, addDoc, getDocs, deleteDoc, doc, serverTimestamp, query, orderBy } from "firebase/firestore";
import { motion } from "motion/react";
import { Plus, Trash2, Video, Activity, ListOrdered, MonitorPlay, Sparkles } from "lucide-react";
import { GoogleGenAI } from "@google/genai";

const ai = process.env.GEMINI_API_KEY ? new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY }) : null;

interface Stream {
  id: string;
  title: string;
  streamerId: string;
  status: string;
  viewers: number;
}

export default function Admin() {
  const [streams, setStreams] = useState<Stream[]>([]);
  const [newStream, setNewStream] = useState({ title: "", streamerId: "", url: "", description: "" });
  const [loading, setLoading] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);

  useEffect(() => {
    fetchStreams();
  }, []);

  const generateDescription = async () => {
    if (!newStream.title || !ai) return;
    setAiLoading(true);
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Generate a high-octane, hype-filled gaming livestream description for a stream titled: "${newStream.title}". Keep it under 200 characters and use gaming lingo.`,
      });
      const text = response.text || "";
      setNewStream(prev => ({ ...prev, description: text }));
    } catch (err) {
      console.error("AI generation failed:", err);
    } finally {
      setAiLoading(false);
    }
  };

  const fetchStreams = async () => {
    const q = query(collection(db, "streams"), orderBy("createdAt", "desc"));
    const snapshot = await getDocs(q);
    setStreams(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Stream)));
  };

  const handleCreate = async (e: FormEvent) => {
    e.preventDefault();
    if (!newStream.title || !newStream.streamerId) return;
    setLoading(true);
    try {
      await addDoc(collection(db, "streams"), {
        ...newStream,
        status: "live", // Hardcoded to live for demo purposes
        viewers: Math.floor(Math.random() * 1000),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setNewStream({ title: "", streamerId: "", url: "", description: "" });
      fetchStreams();
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Confirm node termination?")) return;
    await deleteDoc(doc(db, "streams", id));
    fetchStreams();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="flex items-center justify-between mb-12">
        <div>
          <h1 className="text-4xl font-display font-black uppercase tracking-tighter italic">Command Center</h1>
          <p className="text-white/40 font-mono text-sm uppercase tracking-widest mt-1">Global Broadcast Management</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="bg-[#00FF00]/10 border border-[#00FF00]/30 px-4 py-2 rounded-sm flex items-center gap-2">
            <Activity className="w-4 h-4 text-[#00FF00]" />
            <span className="text-xs font-mono font-bold uppercase tracking-widest">Systems: Operational</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Creation Form */}
        <div className="lg:col-span-1">
          <div className="bg-[#0a0a0a] border border-white/10 p-6 rounded-sm">
            <h2 className="text-lg font-bold uppercase tracking-widest border-b border-white/10 pb-4 mb-6 flex items-center gap-2">
              <Plus className="w-4 h-4 text-[#00FF00]" />
              Initialize Node
            </h2>
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-[10px] uppercase tracking-widest text-white/40 mb-1.5 ml-1">Stream Broadcast Title</label>
                <input 
                  type="text"
                  placeholder="EX: PRO QUALIFIERS - ZONE 4"
                  className="w-full bg-[#151619] border border-white/10 px-4 py-3 text-sm focus:border-[#00FF00] outline-none transition-colors"
                  value={newStream.title}
                  onChange={e => setNewStream({...newStream, title: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-[10px] uppercase tracking-widest text-white/40 mb-1.5 ml-1">Link node ID (UID)</label>
                <input 
                  type="text"
                  placeholder="Streamer User ID"
                  className="w-full bg-[#151619] border border-white/10 px-4 py-3 text-sm focus:border-[#00FF00] outline-none transition-colors"
                  value={newStream.streamerId}
                  onChange={e => setNewStream({...newStream, streamerId: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-[10px] uppercase tracking-widest text-white/40 mb-1.5 ml-1">Broadcast URL (Embed)</label>
                <input 
                  type="text"
                  placeholder="https://..."
                  className="w-full bg-[#151619] border border-white/10 px-4 py-3 text-sm focus:border-[#00FF00] outline-none transition-colors"
                  value={newStream.url}
                  onChange={e => setNewStream({...newStream, url: e.target.value})}
                />
              </div>
              <div>
                <div className="flex justify-between items-center mb-1.5 ml-1">
                  <label className="block text-[10px] uppercase tracking-widest text-white/40">Metadata Description</label>
                  <button 
                    type="button"
                    onClick={generateDescription}
                    disabled={!newStream.title || aiLoading}
                    className="flex items-center gap-1 text-[10px] text-[#00FF00]/60 hover:text-[#00FF00] disabled:opacity-30 transition-colors uppercase font-bold"
                  >
                    <Sparkles className="w-3 h-3" />
                    AI Generate
                  </button>
                </div>
                <textarea 
                  placeholder="System generated or manual input..."
                  rows={3}
                  className="w-full bg-[#151619] border border-white/10 px-4 py-3 text-sm focus:border-[#00FF00] outline-none transition-colors resize-none"
                  value={newStream.description}
                  onChange={e => setNewStream({...newStream, description: e.target.value})}
                />
              </div>
              <button 
                type="submit"
                disabled={loading}
                className="w-full bg-[#00FF00] text-black font-black uppercase tracking-tighter py-4 hover:scale-[1.02] active:scale-95 transition-all disabled:opacity-50"
              >
                {loading ? "Initializing..." : "Broadcast Launch"}
              </button>
            </form>
          </div>
        </div>

        {/* List */}
        <div className="lg:col-span-2">
          <div className="bg-[#0a0a0a] border border-white/10 rounded-sm">
            <div className="p-6 border-b border-white/10 flex items-center justify-between">
              <h2 className="text-lg font-bold uppercase tracking-widest flex items-center gap-2">
                <ListOrdered className="w-4 h-4 text-[#00FF00]" />
                Active Node Matrix
              </h2>
              <span className="text-[10px] font-mono text-white/40 bg-white/5 px-2 py-1 uppercase tracking-widest">Count: {streams.length}</span>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-white/5 text-[10px] uppercase tracking-widest opacity-40">
                  <tr>
                    <th className="px-6 py-4 font-medium">Broadcast Node</th>
                    <th className="px-6 py-4 font-medium">Status</th>
                    <th className="px-6 py-4 font-medium text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {streams.map(stream => (
                    <tr key={stream.id} className="hover:bg-white/5 transition-colors group">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-white/5 flex items-center justify-center border border-white/10 group-hover:border-[#00FF00]/30">
                            <Video className="w-5 h-5 text-white/20 group-hover:text-[#00FF00]" />
                          </div>
                          <div>
                            <div className="font-bold text-sm tracking-tight">{stream.title}</div>
                            <div className="text-[10px] font-mono opacity-40 uppercase truncate max-w-[150px]">{stream.id}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <div className={`w-1.5 h-1.5 rounded-full ${stream.status === 'live' ? 'bg-[#00FF00] animate-pulse' : 'bg-white/20'}`} />
                          <span className="text-[10px] font-mono uppercase tracking-widest opacity-60">{stream.status}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button className="p-2 border border-white/10 hover:border-[#00FF00] hover:text-[#00FF00]">
                            <MonitorPlay className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => handleDelete(stream.id)}
                            className="p-2 border border-white/10 hover:border-red-500 hover:text-red-500"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                  {streams.length === 0 && (
                    <tr>
                      <td colSpan={3} className="px-6 py-20 text-center text-white/20 font-mono text-xs uppercase tracking-widest">
                        Zero nodes detected in current matrix scope.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
