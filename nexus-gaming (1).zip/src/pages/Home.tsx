import { useEffect, useState } from "react";
import { collection, query, where, getDocs, limit } from "firebase/firestore";
import { db } from "../lib/firebase";
import { Link } from "react-router-dom";
import { motion } from "motion/react";
import { Play, Radio, Users, Trophy, Zap } from "lucide-react";

interface Stream {
  id: string;
  title: string;
  streamerId: string;
  status: string;
  viewers: number;
  thumbnail?: string;
}

export default function Home() {
  const [streams, setStreams] = useState<Stream[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStreams = async () => {
      const q = query(collection(db, "streams"), where("status", "==", "live"), limit(6));
      const snapshot = await getDocs(q);
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Stream));
      setStreams(data);
      setLoading(false);
    };
    fetchStreams();
  }, []);

  return (
    <main className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative min-h-[85vh] flex items-center justify-center pt-20 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#050505]/50 to-[#050505]" />
          <div className="absolute inset-0 scanlines opacity-50 z-10" />
          <motion.div 
            initial={{ scale: 1.1, opacity: 0 }}
            animate={{ scale: 1, opacity: 0.25 }}
            transition={{ duration: 3 }}
            className="w-full h-full bg-[url('https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80')] bg-cover bg-center"
          />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 text-center">
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <div className="mb-6 inline-flex items-center gap-3 bg-brand/10 border border-brand/20 px-4 py-1.5 rounded-sm">
               <div className="w-2 h-2 bg-brand animate-pulse" />
               <span className="text-[10px] font-mono font-bold text-brand uppercase tracking-[0.4em]">Battle Ready Ecosystem</span>
            </div>
            <h1 className="font-display font-black text-8xl md:text-[16vw] uppercase leading-[0.75] tracking-tighter mb-8 italic drop-shadow-2xl">
              Level <span className="text-brand">UP</span>
            </h1>
            <p className="max-w-2xl mx-auto text-lg text-white/60 font-mono uppercase tracking-[0.2em] mb-12">
              The premier ecosystem for <span className="text-white">competitive livestreaming</span> and elite community interaction.
            </p>
            <div className="flex flex-wrap justify-center gap-6">
              <button className="pubg-btn-primary group">
                <span className="relative z-10 flex items-center gap-3">
                  <Play className="w-5 h-5 fill-black" />
                  Join Arena
                </span>
              </button>
              <button className="pubg-btn-secondary">
                <span className="relative z-10">Explore Meta</span>
              </button>
            </div>
          </motion.div>
        </div>

        {/* Stats Strip */}
        <div className="absolute bottom-0 left-0 right-0 border-t border-white/10 bg-[#0a0a0a]/90 backdrop-blur-xl">
          <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 divide-x divide-white/10">
            {[
              { label: "Active Players", value: "124K+", icon: Users },
              { label: "Live Streams", value: "842", icon: Radio },
              { label: "Tournaments", value: "12", icon: Trophy },
              { label: "Data Flow", value: "1.2GB/s", icon: Zap },
            ].map((stat, i) => (
              <div key={i} className="p-6 flex items-center gap-4 group hover:bg-white/5 transition-colors">
                <stat.icon className="w-5 h-5 text-[#00FF00] group-hover:scale-110 transition-transform" />
                <div>
                  <div className="text-xl font-black font-mono leading-none">{stat.value}</div>
                  <div className="text-[10px] uppercase tracking-widest text-white/40 mt-1">{stat.label}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Live Streams Section */}
      <section className="py-24 bg-[#050505]">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-end justify-between mb-12">
            <div>
              <div className="text-[#00FF00] font-mono text-sm tracking-[0.4em] uppercase mb-2">Broadcasting</div>
              <h2 className="text-4xl font-black uppercase tracking-tighter font-sans italic">Live Nodes</h2>
            </div>
            <Link to="/discover" className="text-sm font-mono uppercase text-white/40 hover:text-[#00FF00]">View Network</Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {loading ? (
              [...Array(3)].map((_, i) => (
                <div key={i} className="aspect-video bg-white/5 animate-pulse rounded-sm" />
              ))
            ) : streams.length > 0 ? (
              streams.map((stream) => (
                <motion.div 
                  key={stream.id}
                  whileHover={{ y: -10 }}
                  className="group"
                >
                  <Link to={`/stream/${stream.id}`} className="block">
                    <div className="relative aspect-video overflow-hidden bg-white/5 border border-white/10 group-hover:border-[#00FF00]/50 transition-colors">
                      <div className="absolute top-4 left-4 z-10">
                        <div className="bg-red-600 px-2 py-0.5 rounded-sm flex items-center gap-1.5 animate-pulse">
                          <div className="w-1.5 h-1.5 bg-white rounded-full" />
                          <span className="text-[10px] font-bold uppercase tracking-widest">Live</span>
                        </div>
                      </div>
                      <div className="absolute bottom-4 right-4 z-10">
                        <div className="bg-black/80 backdrop-blur-md px-2 py-1 rounded-sm text-[10px] font-mono border border-white/20">
                          {stream.viewers.toLocaleString()} VIEWS
                        </div>
                      </div>
                      <img 
                        src={stream.thumbnail || "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80"} 
                        alt={stream.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 opacity-60 group-hover:opacity-100"
                      />
                    </div>
                    <div className="mt-4">
                      <h3 className="font-bold text-lg leading-tight group-hover:text-[#00FF00] transition-colors">{stream.title}</h3>
                      <p className="text-white/40 text-xs font-mono uppercase mt-1 tracking-widest">Node ID: {stream.id.substring(0, 8)}</p>
                    </div>
                  </Link>
                </motion.div>
              ))
            ) : (
              <div className="col-span-full py-20 text-center border border-dashed border-white/10">
                <div className="text-white/20 font-mono uppercase tracking-widest">No active nodes detected in the arena.</div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Marquee Accent */}
      <div className="bg-[#00FF00] py-4 overflow-hidden border-y-2 border-black">
        <motion.div 
          animate={{ x: [0, -1000] }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="flex whitespace-nowrap gap-12"
        >
          {[...Array(10)].map((_, i) => (
            <span key={i} className="text-black font-black text-2xl uppercase tracking-tighter italic">
              Nexus Gaming System // Realtime Engagement // Infinite Streams // 010101 //
            </span>
          ))}
        </motion.div>
      </div>

      {/* Rankings Section */}
      <section className="py-24 bg-[#0a0a0a]">
        <div className="max-w-7xl mx-auto px-4">
           <div className="text-center mb-16">
              <h2 className="text-5xl font-display font-black uppercase tracking-tighter italic mb-4">Elite Tier Rankings</h2>
              <div className="h-1 w-24 bg-[#00FF00] mx-auto" />
           </div>

           <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {[
                { game: "STRIKE SECTOR", players: [
                  { name: "VoidRunner", score: "28,490", kda: "4.2" },
                  { name: "NeonPhantom", score: "26,120", kda: "3.8" },
                  { name: "ZeroDay", score: "24,800", kda: "3.5" },
                ]},
                { game: "ORBITAL BREACH", players: [
                  { name: "Static_X", score: "1.2M", kda: "N/A" },
                  { name: "FluxCollector", score: "980K", kda: "N/A" },
                  { name: "PulseWitch", score: "940K", kda: "N/A" },
                ]}
              ].map((game, i) => (
                <div key={i} className="bg-[#050505] border border-white/10 overflow-hidden">
                   <div className="bg-white/5 px-6 py-4 border-b border-white/10 flex justify-between items-center">
                      <span className="font-mono text-xs text-[#00FF00] uppercase tracking-widest">{game.game}</span>
                      <Trophy className="w-4 h-4 text-[#00FF00]" />
                   </div>
                   <div className="p-4 space-y-2">
                      {game.players.map((p, j) => (
                        <div key={j} className="flex justify-between items-center p-3 hover:bg-white/5 transition-colors group">
                           <div className="flex items-center gap-4">
                              <span className="font-mono text-white/20 text-xs">{j+1}</span>
                              <span className="font-bold uppercase tracking-tighter group-hover:text-[#00FF00] transition-colors">{p.name}</span>
                           </div>
                           <div className="text-right">
                              <div className="font-mono text-xs font-bold">{p.score}</div>
                              <div className="text-[8px] uppercase text-white/30 tracking-widest leading-none">PTS</div>
                           </div>
                        </div>
                      ))}
                   </div>
                </div>
              ))}
           </div>
        </div>
      </section>

      {/* Holo-News Section */}
      <section className="py-24 border-t border-white/10">
         <div className="max-w-7xl mx-auto px-4">
            <div className="flex items-center gap-4 mb-12">
               <div className="h-px flex-1 bg-white/10" />
               <span className="font-mono text-[10px] uppercase tracking-[0.5em] text-[#00FF00]">System Communications</span>
               <div className="h-px flex-1 bg-white/10" />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
               {[
                 { date: "06 MAY", title: "Patch 9.2: Neural Interface Overhaul", category: "SYSTEM" },
                 { date: "04 MAY", title: "Global Finals: Prize Pool Reaches $12M", category: "ELITE" },
                 { date: "01 MAY", title: "New Map: Distorted Reality - Live Now", category: "ARENA" },
                 { date: "28 APR", title: "Nexus Community Milestone: 1M Nodes", category: "SOCIAL" },
               ].map((news, i) => (
                 <div key={i} className="group cursor-pointer">
                    <div className="text-[10px] font-mono text-[#00FF00] mb-2">{news.date} // {news.category}</div>
                    <h3 className="font-bold text-sm uppercase tracking-tight leading-snug group-hover:underline underline-offset-4 decoration-[#00FF00]">
                       {news.title}
                    </h3>
                 </div>
               ))}
            </div>
         </div>
      </section>
    </main>
  );
}
