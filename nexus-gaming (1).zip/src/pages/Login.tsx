import { useState, FormEvent } from "react";
import { signInWithPopup, GoogleAuthProvider, browserSessionPersistence, setPersistence } from "firebase/auth";
import { auth, db } from "../lib/firebase";
import { doc, getDoc, setDoc, serverTimestamp } from "firebase/firestore";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "motion/react";
import { LogIn, Github, Mail, ShieldCheck, KeyRound, Terminal } from "lucide-react";

export default function Login() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [useAdmin, setUseAdmin] = useState(false);
  const [adminCreds, setAdminCreds] = useState({ user: "", pass: "" });
  const navigate = useNavigate();

  const handleGoogleLogin = async () => {
    setLoading(true);
    setError("");
    const provider = new GoogleAuthProvider();
    try {
      await setPersistence(auth, browserSessionPersistence);
      const result = await signInWithPopup(auth, provider);
      
      const userRef = doc(db, "users", result.user.uid);
      const userSnap = await getDoc(userRef);

      if (!userSnap.exists()) {
        await setDoc(userRef, {
          uid: result.user.uid,
          email: result.user.email,
          displayName: result.user.displayName,
          photoURL: result.user.photoURL,
          role: "member",
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
      navigate("/");
    } catch (err) {
      console.error(err);
      setError("Authorization sequence failed. Connection rejected.");
    } finally {
      setLoading(false);
    }
  };

  const handleAdminLogin = (e: FormEvent) => {
    e.preventDefault();
    if (adminCreds.user === "admin" && adminCreds.pass === "admin@123") {
      // Mocking a successful admin session
      localStorage.setItem("nexus_temp_admin", "true");
      // Note: In a real app we'd use custom tokens or claims, 
      // but following user's specific creds request for demo.
      navigate("/");
      window.location.reload(); // Force refresh to pick up localstorage admin
    } else {
      setError("INVALID SIGNATURE. DEPLOYING COUNTERMEASURES.");
    }
  };

  return (
    <div className="min-h-[calc(100vh-64px)] flex items-center justify-center p-4 bg-[#050505] relative overflow-hidden">
      {/* Background Grid */}
      <div className="absolute inset-0 z-0 bg-[linear-gradient(to_right,#151515_1px,transparent_1px),linear-gradient(to_bottom,#151515_1px,transparent_1px)] bg-[size:40px_40px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]" />

      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="w-full max-w-md bg-[#0a0a0a] border border-white/10 p-8 shadow-2xl relative z-10"
      >
        <div className="absolute -top-24 -left-24 w-48 h-48 bg-[#00FF00]/5 blur-[100px]" />
        
        <div className="relative z-10 text-center mb-8">
          <div className="inline-block bg-[#00FF00]/10 p-4 rounded-full mb-6 relative">
            <div className="absolute inset-0 bg-[#00FF00]/20 blur-xl animate-pulse rounded-full" />
            <ShieldCheck className="w-12 h-12 text-[#00FF00] relative" />
          </div>
          <h1 className="text-4xl font-display font-black uppercase tracking-tighter italic mb-2">Access Portal</h1>
          <p className="text-white/40 font-mono text-[10px] uppercase tracking-[0.3em]">Establish Secure Link</p>
        </div>

        {error && (
          <motion.div 
            initial={{ opacity: 0, x: -10 }} 
            animate={{ opacity: 1, x: 0 }}
            className="mb-6 p-4 bg-red-500/10 border border-red-500/20 text-red-500 text-[10px] font-mono uppercase tracking-widest text-center"
          >
            {error}
          </motion.div>
        )}

        <div className="space-y-4">
          {!useAdmin ? (
            <>
              <button 
                onClick={handleGoogleLogin}
                disabled={loading}
                className="w-full group bg-white text-black h-12 flex items-center justify-center gap-3 font-bold uppercase tracking-tighter hover:bg-[#00FF00] disabled:opacity-50 transition-all font-sans"
              >
                <LogIn className="w-4 h-4 group-hover:scale-110 transition-transform" />
                {loading ? "Syncing..." : "Identify with Google"}
              </button>

              <div className="relative py-4">
                <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-white/5" /></div>
                <div className="relative flex justify-center text-[10px] uppercase font-mono"><span className="bg-[#0a0a0a] px-2 text-white/20">or override</span></div>
              </div>

              <button 
                onClick={() => setUseAdmin(true)}
                className="w-full bg-white/5 border border-white/10 text-white/70 h-12 flex items-center justify-center gap-3 font-bold uppercase tracking-tighter hover:bg-[#00FF00]/10 hover:border-[#00FF00]/30 transition-all text-xs"
              >
                <Terminal className="w-4 h-4" />
                Manual Command Entry
              </button>
            </>
          ) : (
            <motion.form 
              initial={{ opacity: 0, y: 10 }} 
              animate={{ opacity: 1, y: 0 }}
              onSubmit={handleAdminLogin} 
              className="space-y-4"
            >
              <div className="space-y-1">
                <label className="text-[10px] uppercase tracking-widest text-white/40 ml-1">Agent ID</label>
                <input 
                  type="text" 
                  autoFocus
                  placeholder="admin"
                  className="w-full bg-[#151619] border border-white/10 px-4 py-3 text-sm focus:border-[#00FF00] outline-none transition-colors font-mono"
                  value={adminCreds.user}
                  onChange={e => setAdminCreds({...adminCreds, user: e.target.value})}
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] uppercase tracking-widest text-white/40 ml-1">Cipher Key</label>
                <input 
                  type="password" 
                  placeholder="••••••••"
                  className="w-full bg-[#151619] border border-white/10 px-4 py-3 text-sm focus:border-[#00FF00] outline-none transition-colors font-mono"
                  value={adminCreds.pass}
                  onChange={e => setAdminCreds({...adminCreds, pass: e.target.value})}
                />
              </div>
              <div className="flex gap-2">
                <button 
                  type="button" 
                  onClick={() => setUseAdmin(false)}
                  className="w-1/4 bg-white/5 border border-white/10 text-white font-bold h-12 flex items-center justify-center"
                >
                  Back
                </button>
                <button 
                  type="submit"
                  className="w-3/4 bg-[#00FF00] text-black font-black uppercase tracking-tighter h-12 flex items-center justify-center gap-2"
                >
                  Authenticate
                </button>
              </div>
            </motion.form>
          )}
        </div>

        <div className="mt-12 text-center">
          <div className="text-[9px] font-mono text-white/20 uppercase tracking-[0.2em] leading-relaxed">
            Authorized access only. All interactions logged. Nexus OS v9.2.
          </div>
        </div>
      </motion.div>
    </div>
  );
}
