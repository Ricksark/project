import { Link, useNavigate } from "react-router-dom";
import { User, signOut } from "firebase/auth";
import { auth } from "../lib/firebase";
import { Gamepad2, User as UserIcon, LogOut, LayoutDashboard, Settings, Shield } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";

interface NavbarProps {
  user: User | null;
  isAdmin: boolean;
}

export default function Navbar({ user, isAdmin }: NavbarProps) {
  const navigate = useNavigate();
  const [showPopup, setShowPopup] = useState(false);
  const popupRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (popupRef.current && !popupRef.current.contains(event.target as Node)) {
        setShowPopup(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleLogout = async () => {
    await signOut(auth);
    localStorage.removeItem("nexus_temp_admin");
    setShowPopup(false);
    navigate("/login");
  };

  const isManualAdmin = !user && localStorage.getItem("nexus_temp_admin") === "true";
  const activeUser = user || (isManualAdmin ? { displayName: "SYSTEM ADMIN", email: "admin@nexus.sys", uid: "SYSTEM-V01", photoURL: null } : null);

  return (
    <nav className="sticky top-0 z-50 border-b border-white/10 bg-[#050505]/80 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group cursor-pointer" onClick={() => setShowPopup(false)}>
          <div className="bg-[#00FF00] p-1.5 rounded-sm transform group-hover:rotate-12 transition-transform">
            <Gamepad2 className="w-6 h-6 text-black" />
          </div>
          <span className="font-display font-black text-2xl uppercase tracking-tighter italic">Nexus</span>
        </Link>

        <div className="flex items-center gap-6">
          <Link 
            to="/" 
            className="text-sm font-mono uppercase tracking-widest text-white/70 hover:text-[#00FF00] transition-colors"
          >
            Lobby
          </Link>
          
          {activeUser ? (
            <div className="flex items-center gap-4 relative" ref={popupRef}>
              <button 
                onClick={() => setShowPopup(!showPopup)}
                className="flex items-center gap-3 hover:opacity-80 transition-opacity"
              >
                <div className="text-right hidden md:block">
                  <div className="text-[11px] font-bold uppercase tracking-tighter text-white/90">{activeUser.displayName || "Operator"}</div>
                  <div className="text-[8px] font-mono text-[#00FF00] tracking-widest uppercase opacity-70">ID: {activeUser.uid.substring(0, 8)}</div>
                </div>
                {activeUser.photoURL ? (
                  <img src={activeUser.photoURL} className="w-9 h-9 rounded-sm border border-[#00FF00]/50 shadow-[0_0_10px_rgba(0,255,0,0.2)]" alt="Avatar" />
                ) : (
                  <div className="w-9 h-9 bg-[#111] border border-[#00FF00]/30 flex items-center justify-center rounded-sm">
                    <UserIcon className="w-5 h-5 text-[#00FF00]/50" />
                  </div>
                )}
              </button>

              <AnimatePresence>
                {showPopup && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    className="absolute top-full right-0 mt-4 w-64 bg-[#0a0a0a] border border-white/10 shadow-2xl z-50 p-1"
                  >
                    <div className="p-4 border-b border-white/5 mb-2 bg-white/5">
                       <div className="text-[9px] font-mono text-white/30 uppercase tracking-[0.3em] mb-1 font-bold">Node Identification</div>
                       <div className="text-sm font-display uppercase tracking-wider truncate">{activeUser.email}</div>
                    </div>

                    <div className="space-y-0.5">
                      {user && (
                        <Link 
                          to="/account" 
                          onClick={() => setShowPopup(false)}
                          className="flex items-center gap-3 w-full p-3 text-xs font-mono uppercase tracking-[0.2em] text-white/60 hover:bg-[#00FF00]/10 hover:text-[#00FF00] transition-colors"
                        >
                          <Settings className="w-4 h-4" />
                          Account Matrix
                        </Link>
                      )}
                      
                      {isAdmin && (
                        <Link 
                          to="/admin" 
                          onClick={() => setShowPopup(false)}
                          className="flex items-center gap-3 w-full p-3 text-xs font-mono uppercase tracking-[0.2em] text-[#00FF00] hover:bg-[#00FF00]/10 transition-colors"
                        >
                          <Shield className="w-4 h-4" />
                          Admin Deck
                        </Link>
                      )}

                      <button 
                        onClick={handleLogout}
                        className="flex items-center gap-3 w-full p-3 text-xs font-mono uppercase tracking-[0.2em] text-red-500 hover:bg-red-500/10 transition-colors text-left"
                      >
                        <LogOut className="w-4 h-4" />
                        Disconnect
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ) : (
            <Link 
              to="/login"
              className="bg-brand text-black px-6 py-2 text-sm font-display font-bold uppercase tracking-wide hover:brightness-110 active:scale-95 transition-all shadow-[0_0_15px_rgba(0,255,0,0.2)]"
            >
              Initialize Session
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}
